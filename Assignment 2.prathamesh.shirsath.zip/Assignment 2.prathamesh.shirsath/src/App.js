import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Banner from './components/Banner';
import Static from './components/Static';
import Props from './components/Props';
import PropsImplementation from './components/PropsImplementation';
import Button from './components/Button';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <Header></Header>
      <Banner></Banner>
      <Static></Static>
      <Props name="Prathamesh Shirsath" />
      <PropsImplementation name="prathamesh shirsath" />
      <Button></Button>
      <Footer></Footer>
    </div>
  );
}

export default App;
