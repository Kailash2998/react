import React, { useState } from "react";

function Button() {
  const [message, setMessage] = useState("what is your name?");

  const handleButtonClick = () => {
    setMessage("PRATHAMESH MADHUKAR SHIRSATH");
  };

  return (
    <div className='row2'>
      <h5>{message}</h5>
      <button className="btn" onClick={handleButtonClick}>Click me</button>
    </div>
  );
}

export default Button;

