import React from "react";

function Props(Props) {
    const { name } = Props;

    return (
        <div className='row1'>
           <h5>Props Implementation using functional component</h5>
            Hello {Props.name}
        </div>
    )
}

export default Props;