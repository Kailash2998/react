import React from "react";
import './Banner.css';

function Banner() {
    return (
        <div className="hero-section">
            <div className="hero-content wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
                <h2>REACTJS TRAINNING</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna</p>
                <div className="">
                    <a href="#">LEARN MORE</a>
                </div>
            </div>
        </div>
    )
}

export default Banner;