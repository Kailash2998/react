import React from "react";

class PropsImplementation extends React.Component {
  render() {
    const { name } = this.props;

    return (
      <div className='row1'>
        <h5>Props Implementation using class component</h5>
        Hello {name}
      </div>
    );
  }
}

export default PropsImplementation;